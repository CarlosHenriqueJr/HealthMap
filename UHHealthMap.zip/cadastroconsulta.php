<?php include "conexao.php";  ?>


<!DOCTYPE html>
<html>
  <head>
    
    <meta http-equiv="Content-Type" content="text/html; />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>Cadastro Consulta</title>
<link rel="shortcut icon" href="favicon.ico" >


  <!-- Core CSS File. The CSS code needed to make eventCalendar works -->

<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript" src="jquery-1.10.2.js"></script>

<link rel="stylesheet" href="ui.css">
<script src="jquery-ui.js"></script>

<style type="text/css">
body{

  background: #CC0033;
}

</style>

<script src="jquery.maskMoney.0.2.js" type="text/javascript"></script> 
<script type="text/javascript" src="../maskedinput.js" ></script>


<script src="jquery.autocomplete.js" type="text/javascript"></script>

<script type="text/javascript" src="gera.js"></script>


    
    <meta content="pt-br" http-equiv="Content-Language"/>
    <!--Para chamar a personalização-->
    

    
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="HandheldFriendly" content="true" />
  <!-- TODO add manifest here -->
  <!--<link rel="manifest" href="/assets/manifest.json">-->
  <!-- Add to home screen for Safari on iOS -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="white">
  <meta name="msapplication-TileColor" content="#FF6E00">
    <meta name="apple-mobile-web-app-title" content="S.O.S">
    <script>
      if(/Android/i.test(navigator.userAgent) ) {
        $('title').text("S.O.S");
      }
    </script>
   
<script type="text/javascript">

      $(function() {
    $('#telefone').mask('(00) 90000-0000');

$("#datepicker").datepicker();


         });

</script>
        


     <script>
      if (!window.navigator.standalone) {
        $('head').append("<meta name='smartbanner:title' content='S.O.S'>");
        $('head').append("<meta name='smartbanner:author' content='Eletromecânica'>");
        $('head').append("<meta name='smartbanner:icon-apple' content='IMG-20180419-WA0035.jpg'>");
        $('head').append("<meta name='smartbanner:icon-google' content='IMG-20180419-WA0035.jpg'>");
        $('head').append("<meta name='smartbanner:button' content='Ver'>");
        $('head').append("<meta name='smartbanner:button-url-apple' content=''>");
                $('head').append("<meta name='smartbanner:enabled-platforms' content='android'>");
        $('head').append("<meta name='smartbanner:hide-ttl' content='86400000'>");
      }
    </script>
   
  
  


    <meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="white"/>
<meta name="apple-mobile-web-app-title" content="Ordem de Serviço"/>

<link rel="apple-touch-icon" href="MG-20180419-WA0035.jpg" />
<link rel="apple-touch-icon" sizes="57x57" href="IMG-20180419-WA0035.jpg" />
<link rel="apple-touch-icon" sizes="72x72" href="IMG-20180419-WA0035.jpg" />
<link rel="apple-touch-icon" sizes="76x76" href="IMG-20180419-WA0035.jpg" />
<link rel="apple-touch-icon" sizes="114x114" href="IMG-20180419-WA0035.jpg" />
<link rel="apple-touch-icon" sizes="120x120" href="IMG-20180419-WA0035.jpg" />
<link rel="apple-touch-icon" sizes="144x144" href="IMG-20180419-WA0035.jpg" />
<link rel="apple-touch-icon" sizes="152x152" href="IMG-20180419-WA0035.jpg" />
    
</head>

<body>
<div style="height: 90px;background: #fff; ">
            
            
<div style="width:27%;float:left; padding-top: 35px; padding-left: 20px;"><a href="mapa/index.php"><img src="voltar.jpg" width="30"></a></div>

<div  align="center" style="width:35%;float:left;margin-right: 60px;padding-top: 15px; "><img src="logo2.jpg" width="90"></div>
</div>

<section>
    
      <div><h1>Cadastro de Perfil de Usuário para Consulta <?=$_GET[id]?></h1></div>
    

      <form id="form-contact" action="pagespera.php" method="post" enctype="multipart/form-data" name="ff">
        <div class="input">
          <label for="name">Nome</label>
          <input type="text" id="name" name="nome" Value="Paciente X" placeholder="Nome" required>
        </div>

        
        <div class="input">
          <label for="name">Tipo Sangue</label>
          <input type="text" id="name" name="nome" Value="O Negativo" placeholder="Tipo Sangue" required>
        </div>


 
        <div class="input">
          <label for="name">Email</label>
          <input type="text" id="name" name="nome" Value="paciente@hotmail.com"  placeholder="Email" required>
        </div>

 <div class="input">
          <label for="telefone">Telefone</label>
          <input type="text" id="telefone" name="telefone"  Value="(98) 99195-2344" placeholder="Telefone" required>
        </div>

         <div class="input">
          <label for="telefone">Nome Login</label>
          <input type="text" id="telefone" name="telefone" Value="PacienteXapp" placeholder="Nome Login" required>
        </div>

        <div class="input">
          <label for="telefone">Senha</label>
          <input type="password" id="telefone" name="telefone"  Value="PacienteXapp" placeholder="Senha" required>
        </div>


 
<div style="clear: both;"></div>



 <div class="input txt">
          <label for="placa">Endereço</label>
          <input type="text" name="placa" id="placa" Value="Avenida X, nº X - Bairro X" placeholder="Endereço" required>
        <div style="clear: both;"></div>
        </div> 

<div style="clear: both;"></div>

<div class="input">
          <label for="name">Sexo</label>
          
         
<label class="container">Masculino
  <input type="radio" name="sexo" value="masculino" checked required>
  <span class="checkmark"></span>
</label>

<label class="container">Feminino
  <input type="radio" name="sexo" value="Feminino" required>
  <span class="checkmark"></span>
</label>


        </div>



<div class="input">
          <label for="name">Fumante?</label>
          
         
<label class="container">Sim
  <input type="radio" name="fumante" value="Sim" required>
  <span class="checkmark"></span>
</label>

<label class="container">Não
  <input type="radio" name="fumante" checked  value="Não" required>
  <span class="checkmark"></span>
</label>


        </div>


 <div class="input">
          <label for="name">Hipertensão?</label>
          
         
<label class="container">Sim
  <input type="radio" name="hiper" value="Sim" required>
  <span class="checkmark"></span>
</label>

<label class="container">Não
  <input type="radio" name="hiper" checked value="Não" required>
  <span class="checkmark"></span>
</label>


        </div>       

<div class="input">
          <label for="name">Diabetes?</label>
          
         
<label class="container">Sim
  <input type="radio" name="diabete"  value="Sim" required>
  <span class="checkmark"></span>
</label>

<label class="container">Não
  <input type="radio" name="diabete" checked value="Não" required>
  <span class="checkmark"></span>
</label>


        </div>





        <div class="input">
          <label for="name">Pratica esportes?</label>
          
         
<label class="container">Sim
  <input type="radio" name="esporte" value="Sim" required>
  <span class="checkmark"></span>
</label>

<label class="container">Não
  <input type="radio" name="esporte" checked value="Não" required>
  <span class="checkmark"></span>
</label>


        </div>
<div style="clear: both;"></div>
<div class="input ">
          <label for="telefone">Toma alguma medição?Sim ou Não, se Sim, Qual?</label>
          <input type="text" id="telefone" name="telefone" value="Não"  placeholder="Toma alguma medição? Qual?" required>
        </div>


        <div class="input ">
          <label >Área da Saúde</label>
          <select name="instituicao" required>
            <option value="-"> Escolha uma Área </option>
            <option value="Nutrição"> Nutrição </option>
            <option value="Pediatria"> Pediatria </option>
            <option value="Clínico Geral"> Clínico Geral </option>
            <option value="Odontologia"> Odontologia </option>
            
          </select>
        </div>

        <div class="input txt">
          <label for="telefone">Observação</label>
          <textarea name="observacao" >Sou alérgico a remédio X</textarea>
        </div>




        <div align="center" class="buttons">
          
          <input type="submit" value="Cadastrar"  />
        </div>


       

        
      </form>
    </section>
    




</body>


</html>
