<?php

ob_start();

include "conexao.php";


$latitude= addslashes($_POST['latitude']);
$longitude= addslashes($_POST['longitude']);

$data= addslashes(date("d/m/Y"));

$dia = date('d');

$mes =date('m');

$ano = date('Y');

$nome= addslashes($_POST['nome']);

$imagem= addslashes($_POST['imagem']);

$obra= addslashes($_POST['obra']);

$descricao=addslashes($_POST['descricao']);




mysql_query("insert into geoloc set 


Latitude='$latitude',

Longitude='$longitude',

dia='$dia',

mes='$mes',

ano='$ano',

data='$data',

nome='$nome',

descricao='$descricao',

obra='$obra',

imagem='$imagem'

") or die(mysql_error());



header("location: /2");







?>

