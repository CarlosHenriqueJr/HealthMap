<?php 
@ob_start();

include "conexao.php"; ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no" />


<style >

body{

	font-family: calibri,Verdana, Geneva, sans-serif;

	margin:0px;

	width: 100%;

	}

	

</style>

<?



$ae = mysql_query("SELECT * FROM autenticacao WHERE login='$_POST[login]'");

$rx = mysql_fetch_array($ae);



$login = "$rx[login]"; //armazena o usuário dentro da variável $login

$senha = "$rx[senha]"; //armazena a senha dentro da variável $senha



//se o usuário digitado for igual ao que esta ali em cima, e a senha também

?>

<div style="padding: 50px;">

<div  align="center" ><img src="img/logo.png" width="40%" /></div><br><br>
<DIV align=center>login ou senha não reconhecidos, verifique os dados inseridos<br><br><br><br>
<div align='center' style='font-size:20px;'><a style='text-decoration:none; font-weight:bold; color:#000;' href=index.php>Clique para Voltar </a></div>


</DIV> </div>

<?php

if ($_POST['login'] &&  $_POST['senha'] != ''){
if ($login == $_POST['login'] && $senha == $_POST['senha'])

//entao execute isto

{

//aqui vai entrar a novidade, antes de redirecionarmos

//vamos salvar algumas informações para utilizar depois



//primeiro eu dou o valor 1 para a variável $validacao

$validacao = "1"; //usaremos essa variável para verificar se ele está logado, se o usuário não tiver o valor 1 nessa variável ele não está logado!

$usuario = $_POST['login']; // puxa o nome do usuário digitado no formulario do index.html

//inicio uma Sessao (session e similar a uma gaveta movel)
session_start("painel");


//gravo as informações das variáveis dentro das sessões



$_SESSION['login'] = $usuario;

$_SESSION['validacao'] = $validacao;



echo  $_SESSION['login'];
//Pronto agora redirecione o usuário para a página secreta



//abre a página secretaaaa

header("Location: mapa/index2.php");

}
							  }
//senao


	

else{

//exiba um alerta dizendo que a senha esta errada

?>



<script type="text/javascript">

alert("Você não está logado!");

</script>

<div style="padding: 50px;">

<div  align="center" ><img src="img/logo.png" width="40%" /></div><br><br>
<DIV align=center>login ou senha não reconhecidos, verifique os dados inseridos<br><br><br><br>
<div align='center' style='font-size:20px;'><a style='text-decoration:none; font-weight:bold; color:#000;' href=index.php>Clique para Voltar </a></div>


</DIV> </div>

<?



}

?>