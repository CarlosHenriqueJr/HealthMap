<?php


@ob_start();


include "../conexao.php"; ?>


<?

//Inicia a sessão

session_start("painel");

//agora verifico se ele possui permissão para acessar a página

if ($_SESSION['validacao'] == "1")

{

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Cadastro </title>

       
        <link rel="stylesheet" type="text/css" href="css/estilo.css">
    </head>
 
    <body>

                <div style="height: 90px; ">
            
            
<div style="width:27%;float:left; padding-top: 35px; padding-left: 20px;"><a href="../index.php"><img src="../voltar.jpg" width="30"></a></div>

<div  align="center" style="width:35%;float:left;margin-right: 60px;padding-top: 15px; "><img src="../logo2.jpg" width="90"></div>

<?php

if ($_SESSION['validacao'] == '1'){?>

<div  align="center" style="width:13%;float:left;padding-top: 5px; "> 
    <div style="font-size: 12px; text-align: center; padding-top: 5px;"><strong ><?= $_SESSION['login']?></strong></div>
    <div style="padding-top: 5px; "><img src="../circulo.jpg" width="50"></div>

     </div>

<? } else {
    

}




     ?>



        </div>

    	<div id="mapa" style="height: 540px; width:100%; margin: 0px; ">
        </div>
		
		<script src="js/jquery.min.js"></script>
 
        <!-- Maps API Javascript -->
        <script src="https://maps.google.com/maps/api/js?key=AIzaSyB8fwcY8P1zBfPs_fCvqP1-hUzpIi-pgx4&sensor=false"></script>
        
        <!-- Caixa de informação -->
        <script src="js/infobox.js"></script>
		
        <!-- Agrupamento dos marcadores -->
		<script src="js/markerclusterer.js"></script>
 
        <!-- Arquivo de inicialização do mapa -->
		<script src="js/mapa.js"></script>



    </body>
</html>



<?

} else {

//exiba um alerta dizendo que a senha esta errada

?>


<div style="padding: 50px; font-family: arial;">

<div  align="center" ><img src="../logo2.jpg" width="200" /></div><br><br>
<DIV align=center> Voc&ecirc; n&atilde;o est&aacute; logado!<br><br><br><br>
<div align='center' style='font-size:20px;'><a style='text-decoration:none; font-weight:bold; color:#000;' href=../index.php>Clique para Voltar </a></div>


</DIV> </div>


<?php

}

?>