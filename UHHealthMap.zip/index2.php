<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="jquery.mobile-1.4.5.css">
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript" src="jquery-1.10.2.js"></script>

<link rel="stylesheet" href="jquery-ui.css">

<style type="text/css">
body{

  background: #CC0033;
}

</style>

</head>
<body>


 <div style="height: 250px; background: #fff;  ">
            
            


<div  align="center" style="width:100%;padding-top: 15px; "><img src="logo2.jpg" width="300"></div>


        </div>

<div data-role="page" id="pageone">
  

  <div data-role="main" class="ui-content">
    



<form action="autenticacao.php" method="post"  name="formi"  enctype="multipart/form-data">

<div align="center" >




<div class="input txt">
         
          <input type="text" id="name" style="border-radius:5px;" name="login" placeholder="Login" required>
        </div>

        <div class="input txt">
          
          <input type="password" id="name" style="border-radius:5px;" name="senha" placeholder="Senha" required>
        </div>

<div>Login para demonstração:<br>
 login: junior<br> senha: junior</div><br>

  <div align="center" class="buttons">
          
          <input type="submit" value="Entrar"  />
        </div>





<br>
</form>


</div>

  

 










</div> 

</body>
</html>