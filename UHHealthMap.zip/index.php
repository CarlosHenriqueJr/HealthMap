<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="jquery.mobile-1.4.5.css">
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />



     <meta name="theme-color" content="#CC0033">
   <meta name="apple-mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-title" content="+UH Health Map">
   <meta name="apple-mobile-web-app-status-bar-style" content="black-transparent">  
   <!-- <link rel="apple-touch-startup-image" href="https://ccmpecdn.s3.sa-east-1.amazonaws.com/imagenspedidoonline/logokarolicias.png"> -->

    
   <link rel="apple-touch-icon" href="logo3.jpg"/>
    
  <meta property="og:type" content="website" />
  <meta property="og:title" content="+UH Health Map"/>

    

  <meta property="og:site_name" content="+UH Health Map"/>
  <meta property="og:description" content="Nordest's Power App para hacking RIO"/>
  <meta property="og:locale" content="pt-BR"/>
  <meta property="fb:app_id" content="1030631416997458"/>
  

    <link rel="manifest" href="manifest.json">



<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript" src="jquery-1.10.2.js"></script>

<link rel="stylesheet" href="jquery-ui.css">

<style type="text/css">
body{

  background: #CC0033;
}

</style>

</head>
<body>

 <div style="height: 250px; background: #fff;  ">
            
            <div align="center" style="font-size: 12px; color: #000; font-weight: bold;"> Para Hacking RIo 2020 - Equipe Nordest's Power na Área da Saúde</div>


<div  align="center" style="width:100%;padding-top: 15px; "><img src="logo2.jpg" width="300"></div>


        </div>



<div data-role="page" id="pageone">
  

  <div data-role="main" class="ui-content">
    


<div align="center">

 <div align="center" class="buttons" style="border-top: none;">
           <p align="left"><strong>Novo por aqui? Primeiros Passos</strong></p><br>
          <a href="mapa/" data-transition="slide" style="text-decoration: none; color: #333;"><input type="submit" value="Você é Paciente?"  /></a>
        </div>


    <div align="center" class="buttons" style="border-top: none;">
                <a href="cadastroest.php" data-transition="slide" style="text-decoration: none; color: #333;"><input type="submit" value="Você é Profissional da Saúde?"  /></a>
        </div>

        <div align="center" class="buttons" style="border-top: none;">
                <a href="index2.php" data-transition="slide" style="text-decoration: none; color: #333;"><input type="submit" value="Já tenho cadastro!"  /></a>
        </div>

  </div>




</div>

  

 










</div> 

</body>
</html>